import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import java.util.Collections;


import java.util.List;



/*import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;*/

import org.apache.hadoop.io.*;

import org.apache.hadoop.mapreduce.Reducer;
 

/**
 * In this Reducer Stage 2 Class,
 * Output from the Mapper Stage 2 <Key, Value> Pair will be used as Input
 * Each word IDF Value is calculated in this stage based on IDF Metric Claculation Formula:
 * IDF = ((1+(log(Word Frequency)))* log(Total No of Documents / Document Frequency))
 * IDF Value calculated will be associated with the Key using HashMap and obtained.
 * Cache Technique is used for maintaining the copy of Values for each key for doing many operations with good 
 * Performance Efficiency
 * Output of the Reducer : <Key, Value>
 * @throws IO Exception, Interrupted Exception
 * @author kartik
 * @version 1.0
 * @since 12 Feb 2017
 *
 */


public class WeightedPageRankReducer1 extends Reducer<Text, Text, Text, Text>
{
   
    
	private Text word1=new Text();
	 private Text word2 = new Text();
	 public static Map <String,Double> NoofInLinks = new HashMap<String,Double> ();
	 public static Map <String,Double> SourcePageRanks = new HashMap<String,Double> ();
	 //Configuration conf= new Configuration();
	 //Path path = new Path ("/output/Temp/part-r-00000");
	 //private Text word2 = new Text();
	 //int fileCount;
	 
	  
	  List <Text> cache = new ArrayList<Text> ();
	  List <Text> cache2 = new ArrayList<Text> ();
	  List <Text> cache3 = new ArrayList<Text> ();
	  
	  
	  
	//reduce method accepts the Key Value pairs from mappers, do the aggregation based on keys and produce the final out put
      public void reduce(Text key, Iterable<Text> values,Context reporter) throws IOException,InterruptedException
      {
    	  
    	  /**
    	   * Cache is used for maintaining the Duplicate values for
    	   * doing multiple operations with the values of the key
    	   * associated.
    	   * Performance Efficiency is better while using this Cache Technique.
    	   */
    	  
    	  if(WeightedPageRankMapper1.CollectionInputLinks.contains(key.toString().trim()))
    	  {
    		  System.out.println("Not a Source Node");
    	  }
    	  else
    	  {
    		  SourcePageRanks.put(key.toString().trim(),Double.valueOf(0.2d));
    		  WeightedPageRankReducer3.DestinationPageRanks.put
    		  (key.toString().trim(),Double.valueOf(0.2d));
    		  System.out.println("SourceNode");
    	  }
    	  
    	  
    	  
    	  for (Text val : values)
    	  {
    		  cache.add(new Text(val));
    		  cache2.add(new Text(val));
    		  cache3.add(new Text (val));
    		  //System.out.println("Hello");
    		  
    	  }
    	 
    	  for  (Text val : cache2)
    	  {
    		 if(val.toString().contains("\t"))
    		 {
    		  
    		  String TabSeperator[] = val.toString().split("\t");
    		  Double TotalLinkValue = 0.0d;
    		  Double PageSpecRank = 0.0d;
    		 for(int i=1;i<TabSeperator.length;i++)
    		 {
    			Double InputLinkVal = Double.valueOf(Collections.frequency(WeightedPageRankMapper1.CollectionInputLinks,
    					TabSeperator[i]));
    			
    			TotalLinkValue += InputLinkVal;
    			
    			NoofInLinks.put(TabSeperator[i].toString().trim(),InputLinkVal);
    		 }
    		 for(int i=1;i<TabSeperator.length;i++)
    		 {
    			Double InputLinkVal = Double.valueOf(Collections.frequency(WeightedPageRankMapper1.CollectionInputLinks,
    					TabSeperator[i]));
    			if (TotalLinkValue == 0.0d)
    			{
    				PageSpecRank = 0.0d;
    			}
    			else
    			{
    				PageSpecRank = InputLinkVal/TotalLinkValue; 
    			}
    			
    			
    			word1.set(key);
    			word2.set(TabSeperator[i] + "\t" + "Win" + "\t" +
    			PageSpecRank.toString());
    			reporter.write(word1, word2);
    			
    		 }
    		 }
    		 else
    		 {
    			 word1.set(key);
    			 word2.set(val);
    			 reporter.write(word1,word2);
    		 }
    	  }
    	  
    	  for  (Text val : cache)
    	  {
    		 if(val.toString().contains("\t"))
    		 {
    		  
    		  String TabSeperator[] = val.toString().split("\t");
    		  Double TotalLinkValue = 0.0d;
    		  Double PageSpecRank = 0.0d;
    		 for(int i=1;i<TabSeperator.length;i++)
    		 {
    			Double OutputLinkVal = Double.valueOf(WeightedPageRankMapper1.CollectionOutputLinks.get(TabSeperator[i]));
  			
    			TotalLinkValue += OutputLinkVal;
    			
    			//NoofInLinks.put(TabSeperator[i].toString().trim(),InputLinkVal);
    		 }
    		 for(int i=1;i<TabSeperator.length;i++)
    		 {
    			 Double OutputLinkVal = Double.valueOf(WeightedPageRankMapper1.CollectionOutputLinks.get(TabSeperator[i]));
    					
    			if (TotalLinkValue == 0.0d)
    			{
    				PageSpecRank = 0.0d;
    			}
    			else
    			{
    				PageSpecRank = OutputLinkVal/TotalLinkValue; 
    			}
    			
    			
    			word1.set(key);
    			word2.set(TabSeperator[i] + "\t" + "Wout" + "\t" +
    			PageSpecRank.toString());
    			reporter.write(word1, word2);
    			
    		 }
    		 }
    		 else
    		 {
    			 word1.set(key);
    			 word2.set(val);
    			 reporter.write(word1,word2);
    		 }
    	  }
    	  
    	 
    	cache.clear();  
    	cache2.clear();
    	System.out.println(NoofInLinks);
    	System.out.println(SourcePageRanks);
    	  
      }
      
      
      
     
}
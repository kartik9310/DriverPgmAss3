import java.io.IOException;

//import java.util.Collections;

//import java.util.StringTokenizer;

//import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.lib.input.FileSplit;
//import org.apache.hadoop.mapreduce.Mapper.Context;


	public class WeightedPageRankMapper3 extends 
	Mapper<Text, Text, Text, Text>
	{
		private Text word1 = new Text();
	      private Text word2 = new Text();
	      
	      public void map(Text key, Text value, Context reporter) 
	    		  throws IOException,InterruptedException
	      {
	    	 
	    	  String line  = key.toString().trim();
	    	  System.out.println(line);
	    	  if(line.contains(","))
	    	  {
	    		  String[] KeyValueInterchange = line.split(",");
	    		  word1.set(KeyValueInterchange[0]);
	    		  word2.set(value.toString().trim());
	    		  reporter.write(word1,word2);
	    		  
	    	  }
	    	  else
	    	  {
	    		  System.out.println("Not Possible");
	    	  }
	      }
	}
	      
	    	
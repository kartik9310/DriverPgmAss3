import java.io.IOException;




/*import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;*/

import org.apache.hadoop.io.*;

import org.apache.hadoop.mapreduce.Reducer;
//import org.apache.hadoop.mapreduce.Reducer.Context;
 

/**
 * In this Reducer Stage 2 Class,
 * Output from the Mapper Stage 2 <Key, Value> Pair will be used as Input
 * Each word IDF Value is calculated in this stage based on IDF Metric Claculation Formula:
 * IDF = ((1+(log(Word Frequency)))* log(Total No of Documents / Document Frequency))
 * IDF Value calculated will be associated with the Key using HashMap and obtained.
 * Cache Technique is used for maintaining the copy of Values for each key for doing many operations with good 
 * Performance Efficiency
 * Output of the Reducer : <Key, Value>
 * @throws IO Exception, Interrupted Exception
 * @author kartik
 * @version 1.0
 * @since 12 Feb 2017
 *
 */


public class WeightedPageRankReducer2 extends Reducer<Text, Text, Text, Text>
{
   
    
	private Text word1=new Text();
	 private Text word2 = new Text();
	 
	 public void reduce(Text key, Iterable<Text> values,Context reporter) throws IOException,InterruptedException
     {
		 String multiplyPageRankNode[] = key.toString().trim().split("\t");
		 Double MultiplyPageRankNodeValue = 0.0d;
		 
		 if(WeightedPageRankReducer1.
				 SourcePageRanks.containsKey(multiplyPageRankNode[1]))
		 {
		  MultiplyPageRankNodeValue = Double.valueOf(WeightedPageRankReducer1.
				 SourcePageRanks.get(multiplyPageRankNode[1]));
		 }
		 else
		 {
			 MultiplyPageRankNodeValue = Double.valueOf(0.2d); 
		 }
		 //System.out.println(MultiplyPageRankNodeValue);
		 Double MultiplyNodesInputOutputValue = 1.0d;
		 
		 for (Text val : values)

		 {
			 
			 String line = val.toString().trim();
			 String pageInputLinks[] = line.split("\t");
			 
			 
			  MultiplyNodesInputOutputValue *=Double.valueOf(pageInputLinks[1]);
				 System.out.println(MultiplyNodesInputOutputValue);
				 
			 }
			 Double PageRankValueForNode = MultiplyPageRankNodeValue * MultiplyNodesInputOutputValue;
			 word1.set(multiplyPageRankNode[0].toString().trim()+","+multiplyPageRankNode[1].toString().trim());
			 word2.set(PageRankValueForNode.toString());
			
			 
			 reporter.write(word1,word2);

		 }
     }



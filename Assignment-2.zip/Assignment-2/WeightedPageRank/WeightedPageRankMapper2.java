import java.io.IOException;

//import java.util.Collections;

//import java.util.StringTokenizer;

//import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.lib.input.FileSplit;
//import org.apache.hadoop.mapreduce.Mapper.Context;


	public class WeightedPageRankMapper2 extends 
	Mapper<Text, Text, Text, Text>
	{
		private Text word1 = new Text();
	      private Text word2 = new Text();
	      
	      public void map(Text key, Text value, Context reporter) 
	    		  throws IOException,InterruptedException
	      {
	    	 
	    	  String line  = value.toString();
	    	  if(line.contains("\t"))
	    	  {
	    		  String[] KeyValueInterchange = line.split("\t");
	    		  word1.set(KeyValueInterchange[0] + "\t" + key.toString().trim());
	    		  word2.set(KeyValueInterchange[1] + "\t" + KeyValueInterchange[2]);
	    		  reporter.write(word1,word2);
	    		  
	    	  }
	    	  else
	    	  {
	    		  System.out.println("Nodes with No Outgoing Edges");
	    	  }
	    	
	    	  
	      }
	      
	}

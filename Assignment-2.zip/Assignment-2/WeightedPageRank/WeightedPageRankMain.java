//import java.util.HashSet;

//import java.util.Set;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
//import org.apache.hadoop.io.DoubleWritable;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
//import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class WeightedPageRankMain {

	/**
	 * @param args
	 */
	//public static Set<String> NODES = new HashSet<String>();
	
	
	@SuppressWarnings("rawtypes")
	public static void main(String[] args) throws Exception {
		
		String outputTempDir = "/output/WtPgRank0";
		String outputTempDir1 = "/output/WtPgRank1";
		String outputTempDir2 = "/output/WtPgRank2";
		Configuration conf = new Configuration();
		
		
		Job job1 = Job.getInstance(conf, "JOB_1");
		Job job2 = Job.getInstance(conf, "JOB_2");
		Job job3 = Job.getInstance(conf, "JOB_3");
		
		
		
		
		job1.setMapperClass(WeightedPageRankMapper1.class);
	    job1.setReducerClass(WeightedPageRankReducer1.class);
	    job1.setInputFormatClass(TextInputFormat.class);
	    job1.setMapOutputKeyClass(Text.class);
	    job1.setMapOutputValueClass(Text.class);
	    job1.setOutputKeyClass(Text.class);
	    job1.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job1, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job1, new Path(outputTempDir));
	    //job1.waitForCompletion(true);
	    
	    boolean success0 = job1.waitForCompletion(true);
	    
	    if(success0)
	    {
	    	job2.setMapperClass(WeightedPageRankMapper2.class);
	    	//job2.setNumReduceTasks(2);
		    job2.setReducerClass(WeightedPageRankReducer2.class);
		    //job2.setReducerClass(WeightedPageRankReducer3.class);
		    job2.setInputFormatClass(KeyValueTextInputFormat.class);
		    job2.setMapOutputKeyClass(Text.class);
		    job2.setMapOutputValueClass(Text.class);
		    job2.setOutputKeyClass(Text.class);
		    job2.setOutputValueClass(Text.class);
		    FileInputFormat.addInputPath(job2, new Path(outputTempDir));
		    FileOutputFormat.setOutputPath(job2, new Path(outputTempDir1));
		    //job2.waitForCompletion(true);	
	    }
	    
	    boolean success1 = job2.waitForCompletion(true);
	    
	    if(success1)
	    {
	    	job3.setMapperClass(WeightedPageRankMapper3.class);
	    	//job2.setNumReduceTasks(2);
		    job3.setReducerClass(WeightedPageRankReducer3.class);
		    //job2.setReducerClass(WeightedPageRankReducer3.class);
		    job3.setInputFormatClass(KeyValueTextInputFormat.class);
		    job3.setMapOutputKeyClass(Text.class);
		    job3.setMapOutputValueClass(Text.class);
		    job3.setOutputKeyClass(Text.class);
		    job3.setOutputValueClass(Text.class);
		    FileInputFormat.addInputPath(job3, new Path(outputTempDir1));
		    FileOutputFormat.setOutputPath(job3, new Path(outputTempDir2));
		    	
	    }
	    
	    boolean success2 = job3.waitForCompletion(true);
	    
	    if(success2)
	    {
	    	Set mapset = (Set) WeightedPageRankReducer3.DestinationPageRanks.entrySet();
	    	Iterator mapIterator = mapset.iterator();
	    	int iteratorCount = 0;
	    	while(mapIterator.hasNext() && iteratorCount < (20))
	    	{
	    		Map.Entry mapEntry = (Map.Entry) mapIterator.next();
	    		
	    		String keyValue = (String) mapEntry.getKey();
	    		
	    		Double valueValue = (Double) mapEntry.getValue();
	    		
	    		System.out.println(Double.valueOf(valueValue).toString().trim() + "\t\t\t" + keyValue.trim());
	    		
	    		
	    		
	    		iteratorCount++;
	    		
	    	}
	    }

	    System.exit(1);
	    
	    
	    /*
	    //System.out.println("NODESIZE =" + NODES.size());
	    
	    
	    	for (int i=1; i<=2;i++){
	    		if(success0)
	    	    {
	    		
	    		String outputTempDir1 = "/output/PgRank"+i;
	    	Job job2 = Job.getInstance(conf, "JOB_ITERATION_"+i);
	    	job2.setMapperClass(pageRankMapper2.class);
	        job2.setReducerClass(PageRankReducer2.class);
	        job2.setInputFormatClass(KeyValueTextInputFormat.class);
	        job2.setMapOutputKeyClass(Text.class);
	        job2.setMapOutputValueClass(Text.class);
	        job2.setOutputKeyClass(Text.class);
	        job2.setOutputValueClass(Text.class);
	        FileInputFormat.addInputPath(job2, new Path(outputTempDir));
	        FileOutputFormat.setOutputPath(job2, new Path(outputTempDir1));
	        success0 = job2.waitForCompletion(true);
	        outputTempDir = outputTempDir1;
	    	}
	    	}
	    	
	    	if(success0)
	    	{
	    		
	    	
	    	Job job3 = Job.getInstance(conf, "JOB_3");
			
			
			
			job3.setMapperClass(PageRankMapper3.class);
		    job3.setSortComparatorClass(MyComparator.class);
		    job3.setInputFormatClass(KeyValueTextInputFormat.class);
		    job3.setMapOutputKeyClass(DoubleWritable.class);
		    job3.setMapOutputValueClass(Text.class);
		    job3.setOutputKeyClass(DoubleWritable.class);
		    job3.setOutputValueClass(Text.class);
		    FileInputFormat.addInputPath(job3, new Path(outputTempDir));
		    FileOutputFormat.setOutputPath(job3, new Path(args[1]));
		    success0 = job3.waitForCompletion(true);
	    	}
	    	
	    	
	    	
	    	
	        System.exit(1);*/
	    	
	    
	}
	    
		
	}



import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
//import java.util.Collections;

//import java.util.StringTokenizer;

//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.lib.input.FileSplit;


	public class WeightedPageRankMapper1 extends Mapper<LongWritable, Text, Text, Text>
	{
	      //hadoop supported data types
	      
	      private Text word1 = new Text();
	      private Text word2 = new Text();
	      public static ArrayList<String> CollectionInputLinks  = new ArrayList<String>();
	      public static Map<String , Double> CollectionOutputLinks  = new HashMap<String , Double>();
	      
	      
	      
	      public void map(LongWritable key, Text value, Context reporter) throws IOException,InterruptedException
	      {
	    	 
	    	  String line  = value.toString();
	    	  StringBuilder node = new StringBuilder();
	    	  line = line.replaceAll("\\t", ",");
	    	  System.out.println(line);
	    	  
	    	  if (line.contains(","))
	    	  {
	    		  String[] edges = line.split(",");
		    	  //String valueForMapper = (String.valueOf(1d));
		    	  word1.set(edges[0].trim());
		    	  for (int i=1;i<edges.length;i++)
		    	  {
		    		  node.append(edges[i]);
		    		  node.append("\t");
		    		  CollectionInputLinks.add(edges[i]);
		    	  }
		    	  word2.set(Double.valueOf(edges.length-1) +"\t" + node.toString().trim());
		    	  CollectionOutputLinks.put(word1.toString(),	Double.valueOf(edges.length-1) );
		    	  
		    	  
	    	  }
	    	  else
	    	  {
	    		  String edgeSource = line;
	    		  //String valueForMapper = String.valueOf(1d) ;
		    	  word1.set(edgeSource.trim());
		    	  word2.set(Double.valueOf(0).toString());
		    	  CollectionOutputLinks.put(word1.toString(),	Double.valueOf(0) );
		    	 
	    	}
	    		  
	    	  
	    	  
	    	  System.out.println(CollectionOutputLinks);
	          
	          reporter.write(word1,word2);
	             
	      }
	}


import java.io.IOException;

import java.util.HashMap;
import java.util.Map;





/*import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;*/

import org.apache.hadoop.io.*;

import org.apache.hadoop.mapreduce.Reducer;
//import org.apache.hadoop.mapreduce.Reducer.Context;
 

/**
 * In this Reducer Stage 2 Class,
 * Output from the Mapper Stage 2 <Key, Value> Pair will be used as Input
 * Each word IDF Value is calculated in this stage based on IDF Metric Claculation Formula:
 * IDF = ((1+(log(Word Frequency)))* log(Total No of Documents / Document Frequency))
 * IDF Value calculated will be associated with the Key using HashMap and obtained.
 * Cache Technique is used for maintaining the copy of Values for each key for doing many operations with good 
 * Performance Efficiency
 * Output of the Reducer : <Key, Value>
 * @throws IO Exception, Interrupted Exception
 * @author kartik
 * @version 1.0
 * @since 12 Feb 2017
 *
 */


public class WeightedPageRankReducer3 extends Reducer<Text, Text, Text, Text>
{
   
    
	private Text word1=new Text();
	 private Text word2 = new Text();
	 public static Map <String,Double> DestinationPageRanks = new HashMap<String,Double>();
	 
	 public void reduce(Text key, Iterable<Text> values,Context reporter) throws IOException,InterruptedException
     {
		 double sumofPageRank = 0.0d;
		 
		 for(Text val : values)
		 {
			 sumofPageRank += Double.valueOf(val.toString());
		}
		 
		 
		 Double PageRankNodeValue1 = (0.8d)*Double.valueOf(sumofPageRank);
		 Double PageRankNodeValue = (0.2d)+PageRankNodeValue1;
		 System.out.println(PageRankNodeValue);
		 
		 
		 word1.set(key.toString());
		 word2.set(Double.valueOf(PageRankNodeValue).toString());
		 DestinationPageRanks.put(key.toString(),Double.valueOf(PageRankNodeValue)
				 );
		 reporter.write(word1,word2);
		 
		 System.out.println(DestinationPageRanks);
		 
		 
		 
		 
		 
		 
		 
		 
     }
}
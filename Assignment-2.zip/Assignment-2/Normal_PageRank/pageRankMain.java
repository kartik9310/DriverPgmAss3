import java.util.HashSet;

import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class pageRankMain {

	/**
	 * @param args
	 */
	public static Set<String> NODES = new HashSet<String>();
	
	
	public static void main(String[] args) throws Exception {
		
		String outputTempDir = "/output/pgRank0";
		
		
		Configuration conf = new Configuration();
		FileSystem hdfs = FileSystem.get(conf);
		
		
		Job job1 = Job.getInstance(conf, "JOB_1");
		
		
		
		
		job1.setMapperClass(pageRankMapper1.class);
	    
	    job1.setInputFormatClass(TextInputFormat.class);
	    job1.setMapOutputKeyClass(Text.class);
	    job1.setMapOutputValueClass(Text.class);
	    job1.setOutputKeyClass(Text.class);
	    job1.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job1, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job1, new Path(outputTempDir));
	    
	    
	    boolean success0 = job1.waitForCompletion(true);
	    //System.out.println("NODESIZE =" + NODES.size());
	    
	    
	    	for (int i=1; i<=15;i++){
	    		if(success0)
	    	    {
	    		
	    		String outputTempDir1 = "/output/pgRank"+i;
	    	Job job2 = Job.getInstance(conf, "JOB_ITERATION_"+i);
	    	Path Input = new Path(outputTempDir);
	    	Path Output = new Path(outputTempDir1);
	    	job2.setMapperClass(pageRankMapper2.class);
	        job2.setReducerClass(PageRankReducer3.class);
	        job2.setInputFormatClass(KeyValueTextInputFormat.class);
	        job2.setMapOutputKeyClass(Text.class);
	        job2.setMapOutputValueClass(Text.class);
	        job2.setOutputKeyClass(Text.class);
	        job2.setOutputValueClass(Text.class);
	        System.out.println(outputTempDir);
	        System.out.println(outputTempDir1);
	        FileInputFormat.addInputPath(job2, Input);
	        FileOutputFormat.setOutputPath(job2, Output);
	        success0 = job2.waitForCompletion(true);
	        
	        if(hdfs.exists(Input))
	        {
	        	hdfs.delete(Input,true);
	        }
	        outputTempDir = outputTempDir1;
	    	}
	    	}
	    	
	    	if(success0)
	    	{
	    		
	    	
	    	Job job3 = Job.getInstance(conf, "JOB_3");
			
			
			
			job3.setMapperClass(PageRankMapper3.class);
		    job3.setSortComparatorClass(MyComparator.class);
		    job3.setInputFormatClass(KeyValueTextInputFormat.class);
		    job3.setMapOutputKeyClass(DoubleWritable.class);
		    job3.setMapOutputValueClass(Text.class);
		    job3.setOutputKeyClass(DoubleWritable.class);
		    job3.setOutputValueClass(Text.class);
		    FileInputFormat.addInputPath(job3, new Path(outputTempDir));
		    FileOutputFormat.setOutputPath(job3, new Path(args[1]));
		    success0 = job3.waitForCompletion(true);
	    	}
	    		
	    	
	    	
	    	
	        System.exit(1);
	    	
	    
	}
	    
		
	}



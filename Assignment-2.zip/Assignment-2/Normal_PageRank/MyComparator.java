

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;


/**
 * UserDefined MyComparator Class for TreeMap
 * TreeMap a Comparator already pre-defined in the Class
 * which will always sort the keys inserted into the TreeMap
 * in Ascending Order default.
 * 
 * So, In this Class, we are overriding the method compare
 * such that the Tree Map will give us the sort in 
 * DESCENDING ORDER of the Keys.
 * 
 * This is used for sorting the Normalized IDF - metric Values added to TreeMap
 * in Descending Order.
 * 
 * Takes the Input as Double Values
 * 
 * compare method takes two double values and check which one is big
 * (Descending Order) of keys and stores the same way to Tree Map implemented
 * in SumReducer Java Class.
 * 
 * @author kartik
 *
 */

public class MyComparator extends WritableComparator{
		protected MyComparator(){
			super(DoubleWritable.class,true);
		}
		
		@SuppressWarnings("rawtypes")
		@Override
		public int compare(WritableComparable w1,WritableComparable w2)
		{
			DoubleWritable key1 = (DoubleWritable)w1;
			DoubleWritable key2 = (DoubleWritable)w2;
			
			return -1 * key1.compareTo(key2);
		}
}

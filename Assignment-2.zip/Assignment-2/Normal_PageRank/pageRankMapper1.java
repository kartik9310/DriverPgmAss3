import java.io.IOException;

//import java.util.StringTokenizer;

//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.lib.input.FileSplit;


	public class pageRankMapper1 extends Mapper<LongWritable, Text, Text, Text>
	{
	      //hadoop supported data types
	      
	      private Text word1 = new Text();
	      private Text word2 = new Text();
	      
	      
	      
	      public void map(LongWritable key, Text value, Context reporter) throws IOException,InterruptedException
	      {
	    	 
	    	  String line  = value.toString();
	    	  StringBuilder node = new StringBuilder();
	    	  line = line.replaceAll("\\t", ",");
	    	  System.out.println(line);
	    	  
	    	  if (line.contains(","))
	    	  {
	    		  String[] edges = line.split(",");
		    	  String valueForMapper = (String.valueOf(1d));
		    	  word1.set(edges[0].trim());
		    	  for (int i=1;i<edges.length;i++)
		    	  {
		    		  node.append(edges[i]);
		    		  node.append("\t");
		    	  }
		    	  word2.set(valueForMapper.trim() +"\t" + node.toString().trim());
		    	  pageRankMain.NODES.add(edges[0]);
	    	  }
	    	  else
	    	  {
	    		  String edgeSource = line;
	    		  String valueForMapper = String.valueOf(1d) ;
		    	  word1.set(edgeSource.trim());
		    	  word2.set(valueForMapper.trim());
		    	  pageRankMain.NODES.add(edgeSource);
	    	}
	    		  
	    	  
	    	  
	    	  
	          
	          reporter.write(word1,word2);
	             
	      }
	}


import java.io.IOException;

//import java.util.StringTokenizer;

//import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.lib.input.FileSplit;


	public class pageRankMapper2 extends Mapper<Text, Text, Text, Text>
	{
	      //hadoop supported data types
	      
	      private Text word1 = new Text();
	      private Text word2 = new Text();
	      private Text word3 = new Text();
	      private Text word4 = new Text();
	      
	      
	      
	      public void map(Text key, Text value, Context reporter) throws IOException,InterruptedException
	      {
	    	 
	    	  String line  = value.toString();
	    	  StringBuilder node = new StringBuilder();
	    	  line = line.replaceAll("\\t", ",");
	    	  //System.out.println(line);
	    	  
	    	  if (line.contains(","))
	    	  {
	    		  word1.set(key);
	    		  String[] valueFromMapper = line.split(",");
	    		  Double pageRank = Double.valueOf(valueFromMapper[0]);
	    		  Double pageValue = Double.valueOf(valueFromMapper.length -1);
	    		  Double pageRankPer = (Double)pageRank/pageValue;
	    		  System.out.println(pageRank + ","+ pageValue + ","+ Double.valueOf(pageRankPer));
		    	  for (int i=1;i<valueFromMapper.length;i++)
		    	  {
		    		node.append(valueFromMapper[i]);
		    		node.append("\t");
		    		word3.set(valueFromMapper[i]);
		    		word4.set(Double.valueOf(pageRankPer).toString().trim());
		    		reporter.write(word3,word4);
		    	  }
		    	  word2.set("EDGE:" +"\t" + node.toString().trim());
		    	  reporter.write(word1, word2);
	    	  }
	    	  else
	    	  {
	    		  word1.set(key);
	    		  word2.set(Double.valueOf(0).toString().trim());
	    		  reporter.write(word1, word2);
	    	}
	   	  
	    	  
	    	  
	    	 
	      }
	}


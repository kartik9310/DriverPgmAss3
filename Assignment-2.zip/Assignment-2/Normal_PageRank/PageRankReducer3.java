import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//import java.util.Iterator;
 
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
 


public class PageRankReducer3 extends Reducer<Text, Text, Text, Text>
{
		private Text valueFromReducer = new Text();
		String keyMapper3;
		  HashMap <String,Double> hmap = new HashMap <String,Double>();
		  List <Text> cache = new ArrayList<Text> ();
		  List <Text> cache2 = new ArrayList<Text> ();
		  
		  
		
		
      //reduce method accepts the Key Value pairs from mappers, do the aggregation based on keys and produce the final out put
      public void reduce(Text key, Iterable<Text> values, Context reporter) throws IOException,InterruptedException
      {
    	  
    	  StringBuilder node = new StringBuilder();  
    	  Double sum = 0.0d;
            /*iterates through all the values available with a key and add them together and give the
            final result as the key and sum of its values*/
    	  
    	  for (Text val : values)
    	  {
    		  cache.add(new Text(val));
    		  cache2.add(new Text(val));
    		  
    		  //System.out.println("Hello");
    		  
    	  }
    	  
    	  for(Text val : cache)
    	  {
    		
    		 if(val.toString().trim().contains("EDGE"))
    		 {
    			 System.out.println("Has Outgoing Edges");
    			 hmap.put(key.toString().trim(),Double.valueOf(sum));
    		 }
    		 else
    		 {
    		 String pageRankVal = val.toString().trim();
     		 Double pageRk = Double.valueOf(pageRankVal);
     		 System.out.println(pageRk);
     		 sum += pageRk;
     		 hmap.put(key.toString().trim(),Double.valueOf(sum));
     		 System.out.println(hmap);
    		 }
    	  }
    	  
          for (Text val : cache2)
          {
        	  String Value = val.toString().trim();
        	  
        	  if(Value.contains("EDGE"))
        		 
        	  {
        		  //System.out.println(Value);
        		 String output[] = Value.split("\t");
        		 
        		 for (int i=1; i<output.length; i++)
        		 {
        			 node.append(output[i]);
        			 node.append("\t");
        			 
        		 }
        		 Double damping_value = (0.2d)/Double.valueOf(pageRankMain.NODES.size());
        		 //Double damping_value = (0.2d)/Double.valueOf(93);
        		 Double pageRankSpec = (0.8d) * hmap.get(key.toString().trim());
        		 Double FinalPageRank = damping_value + pageRankSpec;
        		
        		valueFromReducer.set(FinalPageRank.toString() + "\t" + node.toString().trim());
        		//reporter.write(key, valueFromReducer);
        		break;
        		
        	  }
        	  
        	  else
        	  {
        		 
        		 Double damping_value = (0.2d)/Double.valueOf(pageRankMain.NODES.size());
        		 //Double damping_value = (0.2d)/Double.valueOf(93);
        		 Double pageRankSpec = (0.8d) * hmap.get(key.toString().trim());
        		 Double FinalPageRank = damping_value + pageRankSpec;
        		 valueFromReducer.set(FinalPageRank.toString().trim());
        		 
        	  }
        	
        	  
        	  
          }
           
          reporter.write(key, valueFromReducer);
    	  
    	  
    	
    	  cache.clear();
    	  cache2.clear();
    	  
          
    	  
    	  hmap.clear();   
      }
      
      
}
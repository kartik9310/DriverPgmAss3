import java.io.IOException;


//import java.util.StringTokenizer;

import org.apache.hadoop.io.DoubleWritable;
//import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.lib.input.FileSplit;


	public class PageRankMapper3 extends Mapper<Text, Text, DoubleWritable, Text>
	{
	      //hadoop supported data types
	      
	      private Text word1 = new Text();
	      //private Text word2 = new Text();
	      //public static MultiMap <Double,String> QueryIDFs = new TreeMap <Double,String>(new MyComparator());
	      
	      
	      public void map(Text key, Text value, Context reporter) throws IOException,InterruptedException
	      {
	    	 
	    	  String PageRankValue = value.toString().trim();
	    	  String PageRank[] = PageRankValue.split("\t");
	    	  Double pageRankNumber = Double.valueOf(PageRank[0].toString().trim());
	    	  word1.set(key);
	    		  
	    	  
	    	  
	    	  
	          
	          reporter.write(new DoubleWritable(pageRankNumber),word1);
	          //QueryIDFs.put(pageRankNumber,key.toString().trim());
	             
	      }
	}

